create definer = root@`%` view port_emp as
select `platform-shop`.`sys_user`.`username` AS `No`,
       `platform-shop`.`sys_user`.`username` AS `Name`,
       `platform-shop`.`sys_user`.`password` AS `Pass`,
       `platform-shop`.`sys_user`.`dept_id`  AS `FK_Dept`,
       `platform-shop`.`sys_user`.`mobile`   AS `Tel`,
       `platform-shop`.`sys_user`.`email`    AS `Email`,
       ''                                    AS `SID`,
       ''                                    AS `PinYin`,
       ''                                    AS `UserType`,
       ''                                    AS `OrgNo`,
       ''                                    AS `Idx`,
       ''                                    AS `SignType`
from `platform-shop`.`sys_user`;

-- comment on column port_emp.No not supported: 用户名

-- comment on column port_emp.Name not supported: 用户名

-- comment on column port_emp.Pass not supported: 密码

-- comment on column port_emp.FK_Dept not supported: 部门ID

-- comment on column port_emp.Tel not supported: 手机号

-- comment on column port_emp.Email not supported: 邮箱

