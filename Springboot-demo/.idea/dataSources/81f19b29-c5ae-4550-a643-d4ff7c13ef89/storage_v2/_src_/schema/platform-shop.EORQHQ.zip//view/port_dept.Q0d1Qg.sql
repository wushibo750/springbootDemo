create definer = root@`%` view port_dept as
select `platform-shop`.`sys_dept`.`dept_id`   AS `No`,
       `platform-shop`.`sys_dept`.`name`      AS `Name`,
       `platform-shop`.`sys_dept`.`parent_id` AS `ParentNo`,
       ''                                     AS `OrgNo`,
       ''                                     AS `Leader`,
       ''                                     AS `Idx`,
       ''                                     AS `DeptType`,
       ''                                     AS `NameOfPath`
from `platform-shop`.`sys_dept`;

-- comment on column port_dept.Name not supported: 部门名称

-- comment on column port_dept.ParentNo not supported: 上级部门ID，一级部门为0

